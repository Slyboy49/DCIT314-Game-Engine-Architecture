d under the terms of the MIT license.
*/

#ifndef CAFU_CALIGHTWORLD_HPP_INCLUDED
#define CAFU_CALIGHTWORLD_HPP_INCLUDED

#include "../Common/World.hpp"
#include "GameSys/Entity.hpp"


class CaLightWorldT
{
    public:

    CaLightWorldT(const char* FileName, ModelManagerT& ModelMan, cf::GuiSys::GuiResourcesT& GuiRes);

    const cf::SceneGraph::BspTreeNodeT& GetBspTree() const { return *m_BspTree; }

    double TraceRay(const Vector3dT& Start, const Vector3dT& Ray) const;

    void CreateLightMapsForEnts(const ArrayT< IntrusivePtrT<cf::GameSys::EntityT> >& AllEnts);

    // Forwarded functions.
    void SaveToDisk(const char* FileName) const;


    private:

    WorldT                              m_World;
    const cf::SceneGraph::BspTreeNodeT* m_BspTree;
    cf::ClipSys::CollisionModelStaticT* m_CollModel;
};

#endif
