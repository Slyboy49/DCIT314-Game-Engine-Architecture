

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <conio.h>
#else
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#define _stricmp strcasecmp
#define _strnicmp strncasecmp
#define _getch getchar
#endif

#include <time.h>
#include <stdio.h>
#include <cassert>

#include "Templates/Array.hpp"
#include "Math3D/Matrix3x3.hpp"
#include "Math3D/Plane3.hpp"
#include "Bitmap/Bitmap.hpp"
#include "ConsoleCommands/Console.hpp"
#include "ConsoleCommands/ConsoleInterpreter.hpp"
#include "ConsoleCommands/ConsoleStdout.hpp"
#include "FileSys/FileManImpl.hpp"
#include "GameSys/AllComponents.hpp"
#include "GameSys/CompLightRadiosity.hpp"
#include "GameSys/Entity.hpp"
#include "GameSys/World.hpp"
#include "GuiSys/GuiResources.hpp"
#include "MaterialSystem/Material.hpp"
#include "MaterialSystem/MaterialManager.hpp"
#include "MaterialSystem/MaterialManagerImpl.hpp"
#include "Models/ModelManager.hpp"
#include "SceneGraph/Node.hpp"
#include "SceneGraph/BspTreeNode.hpp"
#include "SceneGraph/FaceNode.hpp"
#include "SoundSystem/SoundShaderManagerImpl.hpp"
#include "SoundSystem/SoundSys.hpp"
#include "ClipSys/CollisionModelMan_impl.hpp"
#include "String.hpp"

#include "CaLightWorld.hpp"

#if defined(_WIN32)
    #if defined(_MSC_VER)
        #define vsnprintf _vsnprintf
    #endif
#endif


static cf::ConsoleStdoutT ConsoleStdout;
cf::ConsoleI* Console=&ConsoleStdout;

static cf::FileSys::FileManImplT FileManImpl;
cf::FileSys::FileManI* cf::FileSys::FileMan=&FileManImpl;

static cf::ClipSys::CollModelManImplT CCM;
cf::ClipSys::CollModelManI* cf::ClipSys::CollModelMan=&CCM;

ConsoleInterpreterI* ConsoleInterpreter=NULL;
MaterialManagerI*    MaterialManager   =NULL;

static SoundShaderManagerImplT s_SSM;
SoundShaderManagerI* SoundShaderManager = &s_SSM;

SoundSysI* SoundSystem = NULL;


const time_t ProgramStartTime=time(NULL);



static const char* GetTimeSinceProgramStart()
{
    const unsigned long TotalSec=(unsigned long)difftime(time(NULL), ProgramStartTime);
    const unsigned long Sec     =TotalSec % 60;
    const unsigned long Min     =(TotalSec/60) % 60;
    const unsigned long Hour    =TotalSec/3600;

    static char TimeString[24];
    sprintf(TimeString, "%2lu:%2lu:%2lu", Hour, Min, Sec);

    return TimeString;
}


static void Error(const char* ErrorText, ...)
{
    va_list ArgList;
    char    ErrorString[256];

    if (ErrorText!=NULL)
    {
        va_start(ArgList, ErrorText);
            vsnprintf(ErrorString, 256, ErrorText, ArgList);
        va_end(ArgList);

        printf("\nFATAL ERROR: %s\n", ErrorString);
    }

    printf("Program aborted.\n\n");
    exit(1);
}










class DiagMatrixT
{
    public:

    
    DiagMatrixT()
    {
    }

    
    void SetSize(unsigned long n)
    {
        const unsigned long NrOfElements=(n*(n+1))/2;

        Data.Clear();
        Data.PushBackEmpty((NrOfElements+15)/16);

        for (unsigned long i=0; i<Data.Size(); i++) Data[i]=0;
    }

    
    char GetValue(unsigned long row, unsigned long col) const
    {
        if (col>row) return GetValue(col, row);

        const unsigned long ElementIdx=(row*(row+1))/2 + col;
        const unsigned long DataIdx   =ElementIdx / 16;     
        const unsigned long DataOfs   =ElementIdx % 16;     

        return char((Data[DataIdx] >> (DataOfs*2)) & 3);
    }

    
    void SetValue(unsigned long row, unsigned long col, char value)
    {
        if (col>row) { SetValue(col, row, value); return; }

        const unsigned long ElementIdx=(row*(row+1))/2 + col;
        const unsigned long DataIdx   =ElementIdx / 16;     
        const unsigned long DataOfs   =ElementIdx % 16;     

        unsigned long ClearMask=~(3ul << (DataOfs*2));      
        unsigned long Val      =value & 3;

        Data[DataIdx]&=ClearMask;
        Data[DataIdx]|=(Val << (DataOfs*2));
    }

    unsigned long GetBytesAlloced() const
    {
        return Data.Size()*sizeof(unsigned long);
    }

    
    
    bool Test();


    private:

    ArrayT<unsigned long> Data;
};


bool DiagMatrixT::Test()
{
    SetSize(3);
    if (Data.Size()<1) return false;

    
    {
        
        
        Data[0]=0;
        unsigned long Val=0;
        for (unsigned long r=0; r<=4; r++)
            for (unsigned long c=0; c<=r; c++)
            {
                SetValue(r, c, char(Val % 4));
                if (GetValue(r, c)!=Val % 4) return false;
                if (GetValue(c, r)!=Val % 4) return false;
                Val++;
            }

        if (Data[0]!=0x24E4E4E4) return false;
    }

    
    {
        
        Data[0]=0;
        unsigned long Val=0;
        for (unsigned long r=0; r<=4; r++)
            for (unsigned long c=0; c<=r; c++)
            {
                SetValue(c, r, char(Val % 4));
                if (GetValue(r, c)!=Val % 4) return false;
                if (GetValue(c, r)!=Val % 4) return false;
                Val++;
            }

        if (Data[0]!=0x24E4E4E4) return false;
    }

    Data[0]=0;
    return true;
}


static double Max3(const VectorT& V)
{
    double m=V.x;

    if (V.y>m) m=V.y;
    if (V.z>m) m=V.z;

    return m;
}


const double REFLECTIVITY=0.3;  


ArrayT<cf::PatchMeshT> PatchMeshes; 

#include "Init2.cpp"    


enum PatchMeshesMutualVisE { NO_VISIBILITY=0, PARTIAL_VISIBILITY=1/*, FULL_VISIBILITY=2*/ };

std::map< const cf::SceneGraph::GenericNodeT*, ArrayT<unsigned long> > NodePtrToPMIndices;
DiagMatrixT PatchMeshesPVS;     

#include "Init1.cpp"    


static unsigned long Count_AllCalls=0;
static unsigned long Count_DivgWarnCalls=0;


void RadiateEnergy(const CaLightWorldT& CaLightWorld, unsigned long PM_i, unsigned long s_i, unsigned long t_i, char n)
{
    cf::PatchMeshT& PatchMesh_i=PatchMeshes[PM_i];

    cf::PatchT    Big_P_i;
    unsigned long Big_P_i_Count=0;

    
    
    Big_P_i.Area=0;

    
    
    for (char y=0; y<n; y++)
        for (char x=0; x<n; x++)
        {
            unsigned long s_=s_i+x;
            unsigned long t_=t_i+y;

            if (PatchMesh_i.WrapsHorz && s_>=PatchMesh_i.Width ) s_-=PatchMesh_i.Width;
            if (PatchMesh_i.WrapsVert && t_>=PatchMesh_i.Height) t_-=PatchMesh_i.Height;

            if (s_>=PatchMesh_i.Width ) continue;
            if (t_>=PatchMesh_i.Height) continue;

            cf::PatchT& P_i=PatchMesh_i.GetPatch(s_, t_);
            if (!P_i.InsideFace) continue;

            Big_P_i_Count++;
            Big_P_i.Coord           +=P_i.Coord;
            Big_P_i.Normal          +=P_i.Normal;
            Big_P_i.Area            +=P_i.Area;
            Big_P_i.UnradiatedEnergy+=P_i.UnradiatedEnergy;

            P_i.UnradiatedEnergy=VectorT(0, 0, 0);
        }

    if (!Big_P_i_Count) return;

    const double NormalLen=length(Big_P_i.Normal);

    
    
    
    
    
    
    
    
    
    
    Big_P_i.Coord*=1.0/Big_P_i_Count;   
    Big_P_i.Normal=(NormalLen>0.000001) ? Big_P_i.Normal/NormalLen : Vector3dT(0, 0, 1);
    Big_P_i.Area/=Big_P_i_Count;
    

    
    const double MinRayLength=sqrt(Big_P_i.Area);

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    const double DIVG_MARGIN=2.1;
    VectorT EnergyBudget=Big_P_i.UnradiatedEnergy*(REFLECTIVITY*DIVG_MARGIN);

    Count_AllCalls++;


    
    for (unsigned long PM_j=0; PM_j<PatchMeshes.Size(); PM_j++)
    {
        
        
        
        
        
        if (PatchMeshesPVS.GetValue(PM_i, PM_j)==NO_VISIBILITY) continue;

        cf::PatchMeshT& PatchMesh_j=PatchMeshes[PM_j];

#if 1
        
        
        const cf::SceneGraph::FaceNodeT* FaceNode_j=dynamic_cast<const cf::SceneGraph::FaceNodeT*>(PatchMesh_j.Node);
        if (FaceNode_j && FaceNode_j->Polygon.Plane.GetDistance(Big_P_i.Coord)<0.1) continue;
#endif

        for (unsigned long Patch_j=0; Patch_j<PatchMesh_j.Patches.Size(); Patch_j++)
        {
            cf::PatchT& P_j=PatchMesh_j.Patches[Patch_j];
            if (!P_j.InsideFace) continue;


            const VectorT Ray      =P_j.Coord-Big_P_i.Coord;
            const double  RayLength=length(Ray);

            if (RayLength<0.5) continue;   

            const VectorT Dir_ij=scale(Ray, 1.0/RayLength);
            const double  cos1  = dot(Big_P_i.Normal, Dir_ij); if (cos1<=0) continue;
            const double  cos2  =-dot(P_j.Normal,     Dir_ij); if (cos2<=0) continue;

            if (CaLightWorld.TraceRay(Big_P_i.Coord, Ray)<1.0) continue;

            
            
            
            
            
            
            
            
            const double SafeRayLength=(RayLength>MinRayLength) ? RayLength : MinRayLength;

         
         
         
            const double Total_ij     =Big_P_i.Area/3.14159265359*cos1*cos2/SafeRayLength/SafeRayLength;

            

            
            
            const VectorT DeltaRadiosity=scale(Big_P_i.UnradiatedEnergy, (Total_ij<1.0) ? REFLECTIVITY*Total_ij : REFLECTIVITY);

            EnergyBudget-=DeltaRadiosity;
            if (EnergyBudget.x<0.0 || EnergyBudget.y<0.0 || EnergyBudget.z<0.0)
            {
                static unsigned long Count_LastWarn=0;

                if (Count_LastWarn!=Count_AllCalls)
                {
                    Count_DivgWarnCalls++;
                    
                    Count_LastWarn=Count_AllCalls;      
                }

                
            }

            P_j.UnradiatedEnergy+=DeltaRadiosity;
            P_j.TotalEnergy     +=DeltaRadiosity;
            P_j.EnergyFromDir   -=Dir_ij*Max3(DeltaRadiosity);  
        }
    }
}


inline static double ComputePatchWeight(unsigned long i, unsigned long Width, double RangeWidth)
{
    const double PatchBegin=double(i  )/Width;
    const double PatchEnd  =double(i+1)/Width;

    double RangeBegin=0.5-RangeWidth*0.5;
    double RangeEnd  =0.5+RangeWidth*0.5;

    assert(PatchBegin<=PatchEnd);
    assert(RangeBegin<=RangeEnd);

    
    if (PatchBegin>=RangeEnd  ) return 0;   
    if (PatchEnd  <=RangeBegin) return 0;   

    if (RangeBegin<PatchBegin) RangeBegin=PatchBegin;
    if (RangeEnd  >PatchEnd  ) RangeEnd  =PatchEnd;

    return (RangeEnd-RangeBegin)/(PatchEnd-PatchBegin);
}


void DirectLighting(const CaLightWorldT& CaLightWorld, const ArrayT< IntrusivePtrT<cf::GameSys::EntityT> >& AllEnts, const char BLOCK_SIZE, const double METERS_PER_WORLD_UNIT)
{
    const cf::SceneGraph::BspTreeNodeT& Map=CaLightWorld.GetBspTree();

    printf("\n%-50s %s\n", "*** PHASE I - performing direct lighting ***", GetTimeSinceProgramStart());


    
    

    
    
    unsigned long LightSourceCount=0;

    for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size(); PatchMeshNr++)
    {
        cf::PatchMeshT& PM     =PatchMeshes[PatchMeshNr];
        const VectorT   RadExit=VectorT(PM.Material->meta_RadiantExitance_Values);

        if (length(RadExit)<0.1) continue;

        LightSourceCount++;
        printf("%5.1f%%\r", (double)PatchMeshNr/PatchMeshes.Size()*100.0);
        fflush(stdout);

        double LongerSideRange =1.0;
        double ShorterSideRange=1.0;

        if (PM.Material->Name=="TechDemo/lights/reactor-light1")
        {
            LongerSideRange =0.77;
            ShorterSideRange=0.49;
        }
        else if (PM.Material->Name=="TechDemo/lights/reactor-trimlight1")
        {
            LongerSideRange =0.25;
            ShorterSideRange=0.55;
        }

        const double WidthRange =(PM.Width>=PM.Height) ? LongerSideRange : ShorterSideRange;
        const double HeightRange=(PM.Width>=PM.Height) ? ShorterSideRange : LongerSideRange;

        
        for (unsigned long t=0; t<PM.Height; t++)
            for (unsigned long s=0; s<PM.Width; s++)
            {
                cf::PatchT& Patch=PM.Patches[t*PM.Width+s];

                
                if (!Patch.InsideFace) continue;

                const double    Weight=ComputePatchWeight(s, PM.Width, WidthRange)*ComputePatchWeight(t, PM.Height, HeightRange);
                const Vector3dT RadExitWeighted=RadExit*Weight;

                Patch.UnradiatedEnergy+=RadExitWeighted;
                Patch.TotalEnergy     +=RadExitWeighted;
                Patch.EnergyFromDir   +=Patch.Normal*Max3(RadExitWeighted);
            }

        
        
        for (unsigned long t=0; t<PM.Height; t+=BLOCK_SIZE)
            for (unsigned long s=0; s<PM.Width; s+=BLOCK_SIZE)
                RadiateEnergy(CaLightWorld, PatchMeshNr, s, t, BLOCK_SIZE);
    }
    printf("1. # area  light sources: %6lu\n", LightSourceCount);


    
    

    ArrayT<bool> PatchMeshIsInPVS;
    PatchMeshIsInPVS.PushBackEmpty(PatchMeshes.Size());

    unsigned int RL_Count = 0;

    
    
    
    for (unsigned int EntNr = 0; EntNr < AllEnts.Size(); EntNr++)
    {
        IntrusivePtrT<cf::GameSys::ComponentRadiosityLightT> RL = dynamic_pointer_cast<cf::GameSys::ComponentRadiosityLightT>(AllEnts[EntNr]->GetComponent("RadiosityLight"));
        if (RL == NULL) continue;

        RL_Count++;

        
        const Vector3dT     PL_Origin    = AllEnts[EntNr]->GetTransform()->GetOriginWS().AsVectorOfDouble();
        const Vector3dT     PL_Dir       = (cf::math::Matrix3x3fT(AllEnts[EntNr]->GetTransform()->GetQuatWS()) * Vector3fT(1, 0, 0)).AsVectorOfDouble();
        const Vector3dT     PL_Intensity = RL->GetColor().AsVectorOfDouble() * RL->GetIntensity();
        const double        cosPLAngle   = cos(RL->GetConeAngle() / 2.0f);
        const unsigned long PL_LeafNr    = Map.WhatLeaf(PL_Origin);

        if (PL_Intensity.x == 0.0 && PL_Intensity.y == 0.0 && PL_Intensity.z == 0.0) continue;

        printf("%5.1f%%\r", double(EntNr) / AllEnts.Size() * 100.0);
        fflush(stdout);

        for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshIsInPVS.Size(); PatchMeshNr++)
            PatchMeshIsInPVS[PatchMeshNr]=false;

        for (unsigned long LeafNr=0; LeafNr<Map.Leaves.Size(); LeafNr++)
        {
            const cf::SceneGraph::BspTreeNodeT::LeafT& L=Map.Leaves[LeafNr];

            if (!Map.IsInPVS(LeafNr, PL_LeafNr)) continue;

            for (unsigned long SetNr=0; SetNr<L.FaceChildrenSet.Size(); SetNr++)
            {
                const ArrayT<unsigned long>& PMIndices=NodePtrToPMIndices[Map.FaceChildren[L.FaceChildrenSet[SetNr]]];

                for (unsigned long i=0; i<PMIndices.Size(); i++)
                    PatchMeshIsInPVS[PMIndices[i]]=true;
            }

            for (unsigned long SetNr=0; SetNr<L.OtherChildrenSet.Size(); SetNr++)
            {
                const ArrayT<unsigned long>& PMIndices=NodePtrToPMIndices[Map.OtherChildren[L.OtherChildrenSet[SetNr]]];

                for (unsigned long i=0; i<PMIndices.Size(); i++)
                    PatchMeshIsInPVS[PMIndices[i]]=true;
            }
        }


        for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size(); PatchMeshNr++)
        {
            if (!PatchMeshIsInPVS[PatchMeshNr]) continue;

            cf::PatchMeshT& PM=PatchMeshes[PatchMeshNr];

#if 1
            
            
            const cf::SceneGraph::FaceNodeT* FaceNode=dynamic_cast<const cf::SceneGraph::FaceNodeT*>(PM.Node);
            if (FaceNode!=NULL && FaceNode->Polygon.Plane.GetDistance(PL_Origin)<0.1) continue;
#endif

            for (unsigned long t=0; t<PM.Height; t++)
                for (unsigned long s=0; s<PM.Width; s++)
                {
                    cf::PatchT& Patch=PM.Patches[t*PM.Width+s];
                    if (!Patch.InsideFace) continue;

                    const VectorT  LightRay      =Patch.Coord-PL_Origin;    
                    const double   LightRayLength=length(LightRay);
                    const VectorT  LightRayDir   =scale(LightRay, 1.0/LightRayLength);
                    const double   LightRayDot   =dot(LightRayDir, Patch.Normal);   

                    
                    if (LightRayDot>0.0) continue;

                    
                    if (dot(LightRayDir, PL_Dir) < cosPLAngle) continue;

                    if (CaLightWorld.TraceRay(PL_Origin, LightRay)<1.0) continue;

                    if (LightRayLength >= Map.GetLightMapPatchSize())
                    {
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        const double    c           = 1.0 / (LightRayLength * METERS_PER_WORLD_UNIT);
                        const Vector3dT DeltaEnergy = scale(PL_Intensity, -REFLECTIVITY*c*c*LightRayDot);

                        Patch.UnradiatedEnergy+=DeltaEnergy;
                        Patch.TotalEnergy     +=DeltaEnergy;
                        Patch.EnergyFromDir   -=LightRayDir*Max3(DeltaEnergy);  
                    }
                    else
                    {
                        
                        
                        
                        
                        const double  c           = 1.0 / (Map.GetLightMapPatchSize() * METERS_PER_WORLD_UNIT);
                        const VectorT DeltaEnergy = scale(PL_Intensity, REFLECTIVITY*c*c);

                        Patch.UnradiatedEnergy+=DeltaEnergy;
                        Patch.TotalEnergy     +=DeltaEnergy;
                        Patch.EnergyFromDir   -=LightRayDir*Max3(DeltaEnergy);  
                    }
                }
        }
    }
    printf("2. # point light sources: %6u\n", RL_Count);
}


#include "Ward97.cpp"   


void PostProcessBorders(const CaLightWorldT& CaLightWorld)
{
    
    
    
    
    
    
    
    
    printf("\n%-50s %s\n", "*** Post-Process Borders ***", GetTimeSinceProgramStart());


    
    

    
    
    
    
    
    
    
    for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size(); PatchMeshNr++)
    {
        cf::PatchMeshT& PM=PatchMeshes[PatchMeshNr];
        ArrayT<bool>    InsideFaceEx;

        for (unsigned long PatchNr=0; PatchNr<PM.Patches.Size(); PatchNr++)
        {
            const Vector3dT& TE=PM.Patches[PatchNr].TotalEnergy;

            
            InsideFaceEx.PushBack(PM.Patches[PatchNr].InsideFace && (TE.x>0.5/255.0 || TE.y>0.5/255.0 || TE.z>0.5/255.0));
        }

        for (unsigned long t=0; t<PM.Height; t++)
            for (unsigned long s=0; s<PM.Width; s++)
            {
                cf::PatchT& Patch=PM.GetPatch(s, t);

                if (InsideFaceEx[t*PM.Width+s]) continue;

                Patch.TotalEnergy =VectorT(0, 0, 0);
                Vector3dT AvgDir  =VectorT(0, 0, 0);    
                double CoveredArea=0.0;

                
                for (char y=0; y<=2; y++)
                    for (char x=0; x<=2; x++)
                    {
                        if (x==1 && y==1) continue;     

                        int Nx=int(s+x)-1;
                        int Ny=int(t+y)-1;

                        if (PM.WrapsHorz)
                        {
                            
                            if (Nx<             0) Nx+=PM.Width;
                            if (Nx>=int(PM.Width)) Nx-=PM.Width;
                        }

                        if (PM.WrapsVert)
                        {
                            
                            if (Ny<              0) Ny+=PM.Height;
                            if (Ny>=int(PM.Height)) Ny-=PM.Height;
                        }

                        if (Nx<              0) continue;   
                        if (Nx>= int(PM.Width)) continue;   
                        if (Ny<              0) continue;   
                        if (Ny>=int(PM.Height)) continue;   

                        if (!InsideFaceEx[Ny*PM.Width+Nx]) continue;

                        const double      RelevantArea=(x!=1 && y!=1) ? 0.25 : 0.5;
                        const cf::PatchT& Neighb      =PM.GetPatch(Nx, Ny);

                        Patch.TotalEnergy+=Neighb.TotalEnergy  *RelevantArea;
                        AvgDir           +=Neighb.EnergyFromDir*RelevantArea;
                        CoveredArea      +=RelevantArea;
                    }

                if (CoveredArea>0.0001)
                {
                    Patch.TotalEnergy  /=CoveredArea;
                    Patch.EnergyFromDir+=AvgDir/CoveredArea;
                }
            }
    }


    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    const double  PATCH_SIZE          =CaLightWorld.GetBspTree().GetLightMapPatchSize();
    unsigned long PatchesWorkedOnCount=0;

    for (unsigned long PatchMesh1Nr=0; PatchMesh1Nr<PatchMeshes.Size(); PatchMesh1Nr++)
    {
        cf::PatchMeshT&                  PM1      =PatchMeshes[PatchMesh1Nr];
        const cf::SceneGraph::FaceNodeT* FaceNode1=dynamic_cast<const cf::SceneGraph::FaceNodeT*>(PM1.Node);

        if (FaceNode1==NULL) continue;

        const Polygon3T<double>& Face1=FaceNode1->Polygon;
        ArrayT<unsigned long>    NearPatchMeshes;

        printf("%5.1f%%\r", (double)PatchMesh1Nr/PatchMeshes.Size()*100.0);
        fflush(stdout);

        
        for (unsigned long PatchMesh2Nr=0; PatchMesh2Nr<PatchMeshes.Size(); PatchMesh2Nr++)
        {
            cf::PatchMeshT&                  PM2      =PatchMeshes[PatchMesh2Nr];
            const cf::SceneGraph::FaceNodeT* FaceNode2=dynamic_cast<const cf::SceneGraph::FaceNodeT*>(PM2.Node);

            if (FaceNode2==NULL) continue;

            const Polygon3T<double>& Face2=FaceNode2->Polygon;

            
            if (PatchMesh1Nr==PatchMesh2Nr) continue;

            
            if (Face1.WhatSide(Face2.Plane, MapT::RoundEpsilon)!=Polygon3T<double>::InIdentical) continue;

            
            const VectorT BorderPadding(PATCH_SIZE, PATCH_SIZE, PATCH_SIZE);

            BoundingBox3T<double> BB1(Face1.Vertices); BB1.Min=BB1.Min-BorderPadding; BB1.Max=BB1.Max+BorderPadding;
            BoundingBox3T<double> BB2(Face2.Vertices); BB2.Min=BB2.Min-BorderPadding; BB2.Max=BB2.Max+BorderPadding;

            if (!BB1.Intersects(BB2)) continue;

            
            NearPatchMeshes.PushBack(PatchMesh2Nr);
        }

        
        

        
        VectorT Face1_U;
        VectorT Face1_V;

        Face1.Plane.GetSpanVectors(Face1_U, Face1_V);

        
        double Face1_SmallestU=dot(Face1.Vertices[0], Face1_U);
        double Face1_SmallestV=dot(Face1.Vertices[0], Face1_V);

        for (unsigned long VertexNr=1; VertexNr<Face1.Vertices.Size(); VertexNr++)
        {
            double u=dot(Face1.Vertices[VertexNr], Face1_U);
            double v=dot(Face1.Vertices[VertexNr], Face1_V);

            if (u<Face1_SmallestU) Face1_SmallestU=u;
            if (v<Face1_SmallestV) Face1_SmallestV=v;
        }

        const VectorT Face1_UV_Origin=scale(Face1.Plane.Normal, Face1.Plane.Dist);
        const VectorT Face1_Safety   =scale(Face1.Plane.Normal, 0.1);

        Polygon3T<double> Patch1Poly;

        Patch1Poly.Plane=dot(Face1.Plane.Normal, cross(Face1_U, Face1_V))<0 ? Face1.Plane : Face1.Plane.GetMirror();
        Patch1Poly.Vertices.PushBackEmpty(4);

        
        for (unsigned long t1=0; t1<PM1.Height; t1++)
            for (unsigned long s1=0; s1<PM1.Width; s1++)
            {
                cf::PatchT&     Patch1=PM1.Patches[t1*PM1.Width+s1];
                ArrayT<double>  Patch1_OverlapRatios;
                ArrayT<VectorT> Patch1_OverlapTotalEnergies;
                ArrayT<VectorT> Patch1_OverlapEnergyFromDirs;

                
                Patch1Poly.Vertices[0]=Face1_UV_Origin+scale(Face1_U, Face1_SmallestU+(s1-1.0)*PATCH_SIZE)+scale(Face1_V, Face1_SmallestV+(t1-1.0)*PATCH_SIZE);
                Patch1Poly.Vertices[1]=Face1_UV_Origin+scale(Face1_U, Face1_SmallestU+ s1     *PATCH_SIZE)+scale(Face1_V, Face1_SmallestV+(t1-1.0)*PATCH_SIZE);
                Patch1Poly.Vertices[2]=Face1_UV_Origin+scale(Face1_U, Face1_SmallestU+ s1     *PATCH_SIZE)+scale(Face1_V, Face1_SmallestV+ t1     *PATCH_SIZE);
                Patch1Poly.Vertices[3]=Face1_UV_Origin+scale(Face1_U, Face1_SmallestU+(s1-1.0)*PATCH_SIZE)+scale(Face1_V, Face1_SmallestV+ t1     *PATCH_SIZE);

                
                
                
                
                
                
                
                
                if (Face1.Encloses(Patch1Poly, true, MapT::RoundEpsilon)) continue;

                
                VectorT Patch1Poly_Center=scale(Patch1Poly.Vertices[0]+Patch1Poly.Vertices[1]+Patch1Poly.Vertices[2]+Patch1Poly.Vertices[3], 0.25)+Face1_Safety;
                double  Patch1Poly_Area  =Patch1Poly.GetArea();

                
                double  MinDistance=3.0*PATCH_SIZE;
                VectorT InnerPointCloseToPatch1;

                for (unsigned long PatchNr=0; PatchNr<PM1.Patches.Size(); PatchNr++)
                {
                    const cf::PatchT& TempPatch=PM1.Patches[PatchNr];

                    
                    
                    if (!TempPatch.InsideFace) continue;

                    double Distance=length(TempPatch.Coord-Patch1Poly_Center);

                    if (Distance<MinDistance)
                    {
                        MinDistance            =Distance;
                        InnerPointCloseToPatch1=TempPatch.Coord;
                    }
                }

                
                if (MinDistance==3.0*PATCH_SIZE) continue;

                
                for (unsigned long NearNr=0; NearNr<NearPatchMeshes.Size(); NearNr++)
                {
                    cf::PatchMeshT&                  PM2      =PatchMeshes[NearPatchMeshes[NearNr]];
                    const cf::SceneGraph::FaceNodeT* FaceNode2=dynamic_cast<const cf::SceneGraph::FaceNodeT*>(PM2.Node);

                    assert(FaceNode2!=NULL);

                    const Polygon3T<double>& Face2=FaceNode2->Polygon;

                    
                    
                    VectorT Face2_U;
                    VectorT Face2_V;

                    Face2.Plane.GetSpanVectors(Face2_U, Face2_V);

                    double Face2_SmallestU=dot(Face2.Vertices[0], Face2_U);   
                    double Face2_SmallestV=dot(Face2.Vertices[0], Face2_V);

                    unsigned long VertexNr;

                    for (VertexNr=1; VertexNr<Face2.Vertices.Size(); VertexNr++)
                    {
                        double u=dot(Face2.Vertices[VertexNr], Face2_U);
                        double v=dot(Face2.Vertices[VertexNr], Face2_V);

                        if (u<Face2_SmallestU) Face2_SmallestU=u;
                        if (v<Face2_SmallestV) Face2_SmallestV=v;
                    }

                    const VectorT Face2_UV_Origin=scale(Face2.Plane.Normal, Face2.Plane.Dist);

                    Polygon3T<double> Patch2Poly;

                    Patch2Poly.Plane=dot(Face2.Plane.Normal, cross(Face2_U, Face2_V))<0 ? Face2.Plane : Face2.Plane.GetMirror();
                    Patch2Poly.Vertices.PushBackEmpty(4);

                    
                    for (unsigned long t2=0; t2<PM2.Height; t2++)
                        for (unsigned long s2=0; s2<PM2.Width; s2++)
                        {
                            const cf::PatchT& Patch2=PM2.Patches[t2*PM2.Width+s2];

                            
                            if (!Patch2.InsideFace) continue;

                            
                            Patch2Poly.Vertices[0]=Face2_UV_Origin+scale(Face2_U, Face2_SmallestU+(s2-1.0)*PATCH_SIZE)+scale(Face2_V, Face2_SmallestV+(t2-1.0)*PATCH_SIZE);
                            Patch2Poly.Vertices[1]=Face2_UV_Origin+scale(Face2_U, Face2_SmallestU+ s2     *PATCH_SIZE)+scale(Face2_V, Face2_SmallestV+(t2-1.0)*PATCH_SIZE);
                            Patch2Poly.Vertices[2]=Face2_UV_Origin+scale(Face2_U, Face2_SmallestU+ s2     *PATCH_SIZE)+scale(Face2_V, Face2_SmallestV+ t2     *PATCH_SIZE);
                            Patch2Poly.Vertices[3]=Face2_UV_Origin+scale(Face2_U, Face2_SmallestU+(s2-1.0)*PATCH_SIZE)+scale(Face2_V, Face2_SmallestV+ t2     *PATCH_SIZE);

                            
                            if (!Patch1Poly.Overlaps(Patch2Poly, false, MapT::RoundEpsilon)) continue;

                            
                            ArrayT< Polygon3T<double> > NewPolygons;

                            Patch2Poly.GetChoppedUpAlong(Patch1Poly, MapT::RoundEpsilon, NewPolygons);
                            if (NewPolygons.Size()==0) Error("PolygonChopUp failed in PostProcessBorders().");

                            
                            
                            const Polygon3T<double>& OverlapPoly      =NewPolygons[NewPolygons.Size()-1];
                            VectorT                  OverlapPolyCenter=OverlapPoly.Vertices[0];

                            for (VertexNr=1; VertexNr<OverlapPoly.Vertices.Size(); VertexNr++)
                                OverlapPolyCenter=OverlapPolyCenter+OverlapPoly.Vertices[VertexNr];

                            OverlapPolyCenter=scale(OverlapPolyCenter, 1.0/double(OverlapPoly.Vertices.Size()))+Face1_Safety;

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            if (CaLightWorld.TraceRay(InnerPointCloseToPatch1, OverlapPolyCenter-InnerPointCloseToPatch1)<1.0) continue;

                            
                            double OverlapRatio=OverlapPoly.GetArea()/Patch1Poly_Area;

                            
                            
                            Patch1_OverlapRatios        .PushBack(OverlapRatio        );
                            Patch1_OverlapTotalEnergies .PushBack(Patch2.TotalEnergy  );
                            Patch1_OverlapEnergyFromDirs.PushBack(Patch2.EnergyFromDir);
                        }
                }


                
                if (Patch1_OverlapRatios.Size()==0) continue;

                double OverlapRatioSum=0.0;

                for (unsigned long OverlapNr=0; OverlapNr<Patch1_OverlapRatios.Size(); OverlapNr++)
                {
                    if (Patch1_OverlapRatios[OverlapNr]<0.000) Error("Negative overlap percentage!");
                    if (Patch1_OverlapRatios[OverlapNr]>1.001) Error("Overlap is greater than 100%%!");

                    OverlapRatioSum+=Patch1_OverlapRatios[OverlapNr];
                }

                if (OverlapRatioSum>1.0)
                {
                    
                    
                    
                    
                    
                    for (unsigned long OverlapNr=0; OverlapNr<Patch1_OverlapRatios.Size(); OverlapNr++)
                        Patch1_OverlapRatios[OverlapNr]/=OverlapRatioSum;
                }
                else
                {
                    
                    
                    Patch1_OverlapRatios        .PushBack(1.0-OverlapRatioSum);
                    Patch1_OverlapTotalEnergies .PushBack(Patch1.TotalEnergy);
                    Patch1_OverlapEnergyFromDirs.PushBack(Patch1.EnergyFromDir);
                }

                Patch1.TotalEnergy  =VectorT(0,0,0);
                Patch1.EnergyFromDir=VectorT(0,0,0);

                for (unsigned long OverlapNr=0; OverlapNr<Patch1_OverlapRatios.Size(); OverlapNr++)
                {
                    Patch1.TotalEnergy  +=scale(Patch1_OverlapTotalEnergies [OverlapNr], Patch1_OverlapRatios[OverlapNr]);
                    Patch1.EnergyFromDir+=scale(Patch1_OverlapEnergyFromDirs[OverlapNr], Patch1_OverlapRatios[OverlapNr]);
                }

                PatchesWorkedOnCount++;
            }
    }

    printf("Borders completed. %lu patches modified in 2nd part.\n", PatchesWorkedOnCount);
}


unsigned long BounceLighting(const CaLightWorldT& CaLightWorld, const char BLOCK_SIZE, double& StopUE, const bool AskForMore, const char* WorldName)
{
    printf("\n%-50s %s\n", "*** PHASE II - performing bounce lighting ***", GetTimeSinceProgramStart());

    unsigned long IterationCount =0;
    unsigned long FullSearchCount=0;

    while (true)
    {
        unsigned long PM_i  =0;
        unsigned long s_i   =0;
        unsigned long t_i   =0;
        double        BestUE=0;     

        
        for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size(); PatchMeshNr++)
        {
            
            const cf::PatchMeshT& PM         =PatchMeshes[PatchMeshNr];
            unsigned long         NrOfSamples=PM.Patches.Size()<10 ? PM.Patches.Size()/2 : 10;

            for (unsigned long SampleNr=0; SampleNr<NrOfSamples; SampleNr++)
            {
                unsigned long s=rand() % PM.Width;      
                unsigned long t=rand() % PM.Height;     

                s=(s/BLOCK_SIZE)*BLOCK_SIZE;
                t=(t/BLOCK_SIZE)*BLOCK_SIZE;

                unsigned long Count =0;
                double        ThisUE=0;

                for (char y=0; y<BLOCK_SIZE; y++)
                    for (char x=0; x<BLOCK_SIZE; x++)
                    {
                        unsigned long s_=s+x;
                        unsigned long t_=t+y;

                        if (PM.WrapsHorz && s_>=PM.Width ) s_-=PM.Width;
                        if (PM.WrapsVert && t_>=PM.Height) t_-=PM.Height;

                        if (s_>=PM.Width ) continue;
                        if (t_>=PM.Height) continue;

                        const cf::PatchT& P_i=PM.Patches[t_*PM.Width+s_];
                        if (!P_i.InsideFace) continue;

                        ThisUE+=P_i.UnradiatedEnergy.x+P_i.UnradiatedEnergy.y+P_i.UnradiatedEnergy.z;
                        Count++;
                    }

                if (!Count) continue;
                ThisUE/=double(Count);

                if (ThisUE>BestUE)
                {
                    PM_i  =PatchMeshNr;
                    s_i   =s;
                    t_i   =t;
                    BestUE=ThisUE;
                }
            }
        }

        
        
        
        if (BestUE<StopUE)
        {
            FullSearchCount++;      

            for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size() && BestUE<StopUE; PatchMeshNr++)
            {
                const cf::PatchMeshT& PM=PatchMeshes[PatchMeshNr];

                for (unsigned long s=0; s<PM.Width; s++)
                    for (unsigned long t=0; t<PM.Height; t++)
                    {
                        const cf::PatchT& Patch = PM.Patches[t*PM.Width + s];

                        if (!Patch.InsideFace) continue;

                        const VectorT& E      = Patch.UnradiatedEnergy;
                        const double   ThisUE = E.x + E.y + E.z;

                        if (ThisUE>BestUE)
                        {
                            PM_i  =PatchMeshNr;
                            s_i   =s;
                            t_i   =t;
                            BestUE=ThisUE;
                        }
                    }
            }
        }

        printf("Iteration%6lu, BestUE %6.2f, PM_i%6lu, FullSearch%4lu (%5.1f%%)\r", IterationCount, BestUE, PM_i, FullSearchCount, 100.0*float(FullSearchCount)/float(IterationCount+1));
        fflush(stdout);

        if (BestUE<StopUE)  
        {
            printf("\n");
            if (!AskForMore) break;

            time_t StartTime=time(NULL);

            printf("\nStopUE value %10.7f has been reached.\n", StopUE);
            printf("Press 'y' to confirm exit and save current result,\n");
            printf("or any other key to divide StopUE by 10 and continue lighting!\n");

            char Key=_getch(); if (Key==0) (void)_getch();

            unsigned long TotalSec=(unsigned long)difftime(time(NULL), StartTime);
            unsigned long Sec     =TotalSec % 60;
            unsigned long Min     =(TotalSec/60) % 60;
            unsigned long Hour    =TotalSec/3600;
            printf("Length of break (waiting for your decision) was %2lu:%2lu:%2lu.\n", Hour, Min, Sec);

            if (Key=='y') break;
            StopUE/=10.0;
        }

        RadiateEnergy(CaLightWorld, PM_i, s_i, t_i, BLOCK_SIZE);
        IterationCount++;

#ifdef _WIN32
        
        if (_kbhit())
        {
            char Key=_getch(); if (Key==0) (void)_getch();

            if (Key==' ')
            {
                printf("\nINTERRUPTED BY USER!\n");
                printf("Enter 'Y' to confirm exit and save current result,\n");
                printf("Enter 'S' to save the intermediate result, then continue,\n");
                printf("or press any other key to continue lighting!\n");

                Key=_getch(); if (Key==0) (void)_getch();

                if (Key=='Y') break;
                if (Key=='S')
                {
                    printf("\n%-50s %s\n", "*** START Saving of Intermediate Results ***", GetTimeSinceProgramStart());
                    ArrayT<cf::PatchMeshT> SafePMs=PatchMeshes;


                    ToneReproduction(CaLightWorld);
                    PostProcessBorders(CaLightWorld);

                    printf("\n%-50s %s\n", "*** Write Patch values back into LightMaps ***", GetTimeSinceProgramStart());
                    for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size(); PatchMeshNr++)
                    {
                        cf::PatchMeshT&               PM     =PatchMeshes[PatchMeshNr];
                        cf::SceneGraph::GenericNodeT* PM_Node=const_cast<cf::SceneGraph::GenericNodeT*>(PM.Node);

                        
                        PM_Node->BackToLightMap(PM, CaLightWorld.GetBspTree().GetLightMapPatchSize());
                    }

                    printf("\n%-50s %s\n", "*** Saving World ***", GetTimeSinceProgramStart());
                    std::string SaveName=std::string(WorldName)+"_";
                    printf("%s\n", SaveName.c_str());
                    CaLightWorld.SaveToDisk(SaveName.c_str());


                    
                    PatchMeshes=SafePMs;
                    printf("\n%-50s %s\n", "*** END Saving of Intermediate Results ***", GetTimeSinceProgramStart());
                }
            }
        }
#endif
    }

    return IterationCount;
}


void Usage()
{
    printf("\n");
    printf("USAGE: CaLight WorldName [OPTIONS]\n");
    printf("\n");
    printf("-gd=somePath   Specifies the game directory of the world. Try for example\n");
    printf("               \"Games/DeathMatch\" or whatever fits on your system.\n");
    printf("-BlockSize n   Radiative block size for faster bounce lighting.\n");
    printf("               n must be in range 1..8, default is 3.\n");
    printf("-StopUE f      Stop value for unradiated energy. 0 < f <= 10, default is 1.0.\n");
    printf("-AskForMore    Asks for a new StopUE value when the old one has been reached.\n");
    printf("-UseBS4DL      Normally, direct area lighting uses a 'BlockSize' value of 1.\n");
    printf("               Use this to use the same value as for bounce lighting.\n");
    printf("-onlyEnts      Process entities only (not the world).\n");
    printf("-fast          Same as \"-BlockSize 5 -UseBS4DL\".\n");
    printf("\n");
    printf("\n");
    printf("EXAMPLES:\n");
    printf("\n");
    printf("CaLight WorldName -AskForMore -gd=Games/DeathMatch\n");
    printf("    I'll start with the default parameters, show you the 'Options' dialog box,\n");
    printf("    light the world WorldName and finally ask you what to do when the\n");
    printf("    StopUE value has been reached.\n");
    printf("    \"Games/DeathMatch\" is searched for this worlds game related stuff.\n");
    printf("\n");
    printf("CaLight WorldName -StopUE 0.1\n");
    printf("    Most worlds of the Cafu demo release are lit with these switches.\n");
    printf("    \".\" (the default directory for -gd) is searched for game related stuff.\n");
    printf("\n");
    printf("CaLight WorldName -BlockSize 1 -StopUE 0.1\n");
    printf("    This is ideal for batch file processing: WorldName is lit without further\n");
    printf("    user questioning and I'll terminate as soon as StopUE has been reached.\n");
    printf("    Note that BlockSize and StopUE are set for high-quality lighting here.\n");
    printf("\n");
    printf("CaLight WorldName -fast\n");
    printf("CaLight WorldName -BlockSize 5 -UseBS4DL\n");
    printf("    Fast and ugly lighting, intended for quick tests during world development.\n");
    exit(1);
}


static void WriteLogFileEntry(const char* WorldPathName, double StopUE, char BlockSize, unsigned long IterationCount)
{
    char          DateTime [256]="unknown";
    char          HostName [256]="unknown";
    char          WorldName[256]="unknown";
    time_t        Time          =time(NULL);
    unsigned long RunningSec    =(unsigned long)difftime(Time, ProgramStartTime);
    FILE*         LogFile       =fopen("CaLight.log", "a");

    if (!LogFile) return;

    strftime(DateTime, 256, "%d.%m.%Y %H:%M", localtime(&Time));
    DateTime[255]=0;

#ifdef _WIN32
    unsigned long Dummy=256;
    if (!GetComputerName(HostName, &Dummy)) sprintf(HostName, "unknown (look-up failed).");
#else
    
    if (gethostname(HostName, 256)) sprintf(HostName, "unknown (look-up failed).");
#endif
    HostName[255]=0;

    if (WorldPathName)
    {
        
        size_t i=strlen(WorldPathName);

        while (i>0 && WorldPathName[i-1]!='/' && WorldPathName[i-1]!='\\') i--;
        strncpy(WorldName, WorldPathName+i, 256);
        WorldName[255]=0;

        
        i=strlen(WorldName);

        while (i>0 && WorldName[i-1]!='.') i--;
        if (i>0) WorldName[i-1]=0;
    }

    
    fprintf(LogFile, "%-16s %-16s%3lu:%02lu:%02lu [%-16s]%8.5f %ux%u%8lu\n", DateTime, WorldName, RunningSec/3600, (RunningSec/60) % 60, RunningSec % 60, HostName, StopUE, BlockSize, BlockSize, IterationCount);
    fclose(LogFile);
}


int main(int ArgC, const char* ArgV[])
{
    cf::GameSys::GetComponentTIM().Init();      
    cf::GameSys::GetGameSysEntityTIM().Init();  
    cf::GameSys::GetWorldTIM().Init();          

    struct CaLightOptionsT
    {
        std::string GameDirName;
        char        BlockSize;
        double      StopUE;
        bool        AskForMore;
        bool        UseBlockSizeForDirectL;
        bool        EntitiesOnly;

        CaLightOptionsT() : GameDirName("."), BlockSize(3), StopUE(1.0), AskForMore(false), UseBlockSizeForDirectL(false), EntitiesOnly(false) {}
    } CaLightOptions;


    
    printf("\n*** Cafu Lighting Utility, Version 3 (%s) ***\n\n\n", __DATE__);

#ifndef _WIN32
    printf("Reminder:\n");
    printf("The Linux version of CaLight is equivalent to the Win32 version, except that\n");
    printf("the 2nd phase (bounce lighting) cannot manually be terminated\n");
    printf("by the user ahead of time.\n\n");
#endif

    
    { DiagMatrixT TestM; if (!TestM.Test()) Error("DiagMatrixT::Test() failed."); }

    if (ArgC<2) Usage();

    
    
    
    cf::FileSys::FileMan->MountFileSystem(cf::FileSys::FS_TYPE_LOCAL_PATH, "./", "");
    
    

    
    for (int CurrentArg=2; CurrentArg<ArgC; CurrentArg++)
    {
        if (_strnicmp(ArgV[CurrentArg], "-gd=", 4)==0)
        {
            CaLightOptions.GameDirName=ArgV[CurrentArg]+4;
        }
        else if (!_stricmp(ArgV[CurrentArg], "-BlockSize"))
        {
            if (CurrentArg+1==ArgC) Error("I can't find a number after \"-BlockSize\"!");
            CurrentArg++;
            CaLightOptions.BlockSize=atoi(ArgV[CurrentArg]);
            if (CaLightOptions.BlockSize<1 || CaLightOptions.BlockSize>8) Error("BlockSize must be in range 1..8.");
        }
        else if (!_stricmp(ArgV[CurrentArg], "-StopUE"))
        {
            if (CurrentArg+1==ArgC) Error("I can't find a number after \"-StopUE\"!");
            CurrentArg++;
            CaLightOptions.StopUE=atof(ArgV[CurrentArg]);
            if (CaLightOptions.StopUE<=0.0 || CaLightOptions.StopUE>10.0) Error("StopUE must be in ]0, 10].");
        }
        else if (!_stricmp(ArgV[CurrentArg], "-AskForMore"))
        {
            CaLightOptions.AskForMore=true;
        }
        else if (!_stricmp(ArgV[CurrentArg], "-UseBS4DL"))
        {
            CaLightOptions.UseBlockSizeForDirectL=true;
        }
        else if (!_stricmp(ArgV[CurrentArg], "-onlyEnts"))
        {
            CaLightOptions.EntitiesOnly=true;
        }
        else if (!_stricmp(ArgV[CurrentArg], "-fast"))
        {
            CaLightOptions.BlockSize=5;
            CaLightOptions.UseBlockSizeForDirectL=true;
        }
        else if (ArgV[CurrentArg][0]==0)
        {
            
            
        }
        else
        {
            printf("\nSorry, I don't know what \"%s\" means.\n", ArgV[CurrentArg]);
            Usage();
        }
    }


    
    static MaterialManagerImplT MatManImpl;

    MaterialManager=&MatManImpl;

    if (MaterialManager->RegisterMaterialScriptsInDir(CaLightOptions.GameDirName+"/Materials", CaLightOptions.GameDirName+"/").Size()==0)
    {
        printf("\nNo materials found in scripts in \"%s/Materials\".\n", CaLightOptions.GameDirName.c_str());
        printf("Please use the -gd=... option in order to specify the game directory name,\n");
        printf("or run CaLight without any parameters for more help.\n");
        Error("No materials found.");
    }


    try
    {
        printf("Loading World '%s'.\n", ArgV[1]);
        ModelManagerT             ModelMan;
        cf::GuiSys::GuiResourcesT GuiRes(ModelMan);
        CaLightWorldT             CaLightWorld(ArgV[1], ModelMan, GuiRes);

        std::string ScriptName = cf::String::StripExt(ArgV[1]) + ".cent";
        ScriptName = cf::String::Replace(ScriptName, "/Worlds/", "/Maps/");
        ScriptName = cf::String::Replace(ScriptName, "\\Worlds\\", "\\Maps\\");

        cf::UniScriptStateT                ScriptState;
        IntrusivePtrT<cf::GameSys::WorldT> ScriptWorld;

        cf::GameSys::WorldT::InitScriptState(ScriptState);

        ScriptWorld = new cf::GameSys::WorldT(
            cf::GameSys::WorldT::RealmOther,
            ScriptState,
            ModelMan,
            GuiRes,
            *cf::ClipSys::CollModelMan,   
            NULL,       
            NULL);      

        ScriptWorld->LoadScript(ScriptName, cf::GameSys::WorldT::InitFlag_OnlyStatic);

        ArrayT< IntrusivePtrT<cf::GameSys::EntityT> > AllEnts;
        ScriptWorld->GetRootEntity()->GetAll(AllEnts);

        unsigned long IterationCount=0;

        if (!CaLightOptions.EntitiesOnly)
        {
            
            const char BlockSize4DirectLighting=CaLightOptions.UseBlockSizeForDirectL ? CaLightOptions.BlockSize : 1;

            printf("\n");
            printf("- BlockSize is %ux%u.\n", CaLightOptions.BlockSize, CaLightOptions.BlockSize);
            printf("- StopUE    is %.3f.\n", CaLightOptions.StopUE);
            printf("- I will %s you for more.\n", CaLightOptions.AskForMore ? "ASK" : "NOT ask");
            printf("- BlockSize for direct lighting is %ux%u.\n", BlockSize4DirectLighting, BlockSize4DirectLighting);

            
            InitializePatches(CaLightWorld);                

            
            for (unsigned long PatchMeshNr = 0; PatchMeshNr < PatchMeshes.Size(); PatchMeshNr++)
            {
                const cf::PatchMeshT& PM = PatchMeshes[PatchMeshNr];

                for (unsigned long PatchNr = 0; PatchNr < PM.Patches.Size(); PatchNr++)
                {
                    const cf::PatchT& Patch = PM.Patches[PatchNr];

                    if (!Patch.InsideFace && (Patch.UnradiatedEnergy != Vector3dT() || Patch.TotalEnergy != Vector3dT()))
                    {
                        Error("There is a patch that is not inside its face, but has energy!");
                    }
                }
            }

            
            for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size(); PatchMeshNr++)
                NodePtrToPMIndices[PatchMeshes[PatchMeshNr].Node].PushBack(PatchMeshNr);

            InitializePatchMeshesPVSMatrix(CaLightWorld);   

            
            DirectLighting(CaLightWorld, AllEnts, BlockSize4DirectLighting, ScriptWorld->GetMillimetersPerWorldUnit() / 1000.0);
            IterationCount=BounceLighting(CaLightWorld, CaLightOptions.BlockSize, CaLightOptions.StopUE, CaLightOptions.AskForMore, ArgV[1]);

            printf("Info: %lu calls to RadiateEnergy() caused %lu potential divergency events.\n", Count_AllCalls, Count_DivgWarnCalls);


            ToneReproduction(CaLightWorld);                                     
            PostProcessBorders(CaLightWorld);

            printf("\n%-50s %s\n", "*** Write Patch values back into LightMaps ***", GetTimeSinceProgramStart());
            for (unsigned long PatchMeshNr=0; PatchMeshNr<PatchMeshes.Size(); PatchMeshNr++)
            {
                cf::PatchMeshT&               PM     =PatchMeshes[PatchMeshNr];
                cf::SceneGraph::GenericNodeT* PM_Node=const_cast<cf::SceneGraph::GenericNodeT*>(PM.Node);

                
                PM_Node->BackToLightMap(PM, CaLightWorld.GetBspTree().GetLightMapPatchSize());
            }
        }

        
        printf("\n%-50s %s\n", "*** Creating entity lightmaps ***", GetTimeSinceProgramStart());
        CaLightWorld.CreateLightMapsForEnts(AllEnts);

        printf("\n%-50s %s\n", "*** Saving World ***", GetTimeSinceProgramStart());
        printf("%s\n", ArgV[1]);
        CaLightWorld.SaveToDisk(ArgV[1]);


        WriteLogFileEntry(ArgV[1], CaLightOptions.StopUE, CaLightOptions.BlockSize, IterationCount);
        printf("\n%-50s %s\n", "COMPLETED.", GetTimeSinceProgramStart());
    }
    catch (const WorldT::LoadErrorT& E)
    {
        printf("\nType \"CaLight\" (without any parameters) for help.\n");
        Error(E.Msg);
    }
    catch (const WorldT::SaveErrorT& E)
    {
        printf("\nType \"CaLight\" (without any parameters) for help.\n");
        Error(E.Msg);
    }
    catch (const cf::GameSys::WorldT::InitErrorT& IE)
    {
        Error(IE.what());
    }

    return 0;
}
