

#ifndef CAFU_CAPVSWORLD_HPP_INCLUDED
#define CAFU_CAPVSWORLD_HPP_INCLUDED

#include "../Common/World.hpp"


struct SuperLeafT
{
    struct NeighbourT
    {
        unsigned long     SuperLeafNr;      
        Polygon3T<double> SubPortal;        
    };

    ArrayT<unsigned long>       LeafSet;    
    ArrayT< Polygon3T<double> > Portals;    
    BoundingBox3T<double>       BB;         
    ArrayT<NeighbourT>          Neighbours; 
};


class CaPVSWorldT
{
    private:

    WorldT                        m_World;
    cf::SceneGraph::BspTreeNodeT* m_BspTree;

    unsigned long SLC_MaxRecursionDepth;
    double        SLC_MinSubTreeFacesArea;

    double     SubTreeFacesArea                   (unsigned long NodeNr) const;
    bool       SuperLeafConditionIsMet            (unsigned long NodeNr, unsigned long RecursionDepth) const;
    void       CreateSuperLeafFromSubTreeRecursive(unsigned long NodeNr, SuperLeafT& SuperLeaf) const;
    SuperLeafT CreateSuperLeafFromSubTree         (unsigned long NodeNr) const;
    void       CreateSuperLeavesRecursive         (unsigned long NodeNr, ArrayT<SuperLeafT>& SuperLeaves, unsigned long RecursionDepth) const;


    public:

    
    CaPVSWorldT(const char* FileName, ModelManagerT& ModelMan, cf::GuiSys::GuiResourcesT& GuiRes, unsigned long SLC_MaxRecursionDepth_, double SLC_MinSubTreeFacesArea_);

    
    
    
    
    
    void CreateSuperLeaves(ArrayT<SuperLeafT>& SuperLeaves) const;

    
    
    unsigned long WhatLeaf(const VectorT& Position) const;

    
    
    double ClipLine(const VectorT& P, const VectorT& U) const;

    
    void StorePVS(const ArrayT<SuperLeafT>& SuperLeaves, const ArrayT<unsigned long>& SuperLeavesPVS);

    
    unsigned long GetChecksumAndPrintStats() const;

    
    void SaveToDisk(const char* FileName) const;
};

#endif
